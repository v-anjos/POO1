package com.poo.prj_polimerfismoherancasobre_poo1;

import com.poo.prj_polimerfismoherancasobre_poo1.models.Pessoa;
import com.poo.prj_polimerfismoherancasobre_poo1.models.PessoaFisica;
import com.poo.prj_polimerfismoherancasobre_poo1.models.PessoaJuridica;

public class Prj_PolimerfismoHerancaSobre_POO1 {

    public static void main(String[] args) {
        // EXEMPLO SOBRECARGA
        /*ExemploSobrecarga es1 = new ExemploSobrecarga();
        
       ExemploSobrecarga es2 = new ExemploSobrecarga("Teste 1", "Teste2");
       
       System.out.println("Resultado:" +es1.somar(3, 5));
       System.out.println("Resultado:" +es1.somar(3, 5, 2));
       System.out.println("Resultado:" +es1.somar(3.0, 5.0));
       System.out.println("Resultado:" +es1.somar(3, 5.0));
       System.out.println("Resultado:" +es1.somar(3.0, 5));*/
        
       Pessoa p = new PessoaFisica();
       Pessoa p1 = new PessoaJuridica();
       
       PessoaFisica pf = new PessoaFisica();
       PessoaJuridica pj = new PessoaJuridica();
       
       
       
       
    }
}

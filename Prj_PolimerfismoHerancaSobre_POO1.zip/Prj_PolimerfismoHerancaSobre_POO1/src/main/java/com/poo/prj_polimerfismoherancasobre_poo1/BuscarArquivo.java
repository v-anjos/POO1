package com.poo.prj_polimerfismoherancasobre_poo1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class BuscarArquivo {
    public String lerArq() throws FileNotFoundException
    {
        String linha = "";
        
        try
        {            
    
        File f = new File ("Objetos.txt");
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        while(br.ready())
        {
         linha = linha +"\n"+ br.readLine();   
        }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return linha;

        
    }
    
}

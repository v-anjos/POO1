package com.poo.prj_polimerfismoherancasobre_poo1.models;

public class PessoaFisica extends Pessoa
{
    private String cpf;
    private String rg;

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }
    
    @Override
    public String cadastrar()
    {
        return "Nome :"+super.getNome(); "CPF: "+this.getCpf(); "RG: "+this.getRg();
    }
    
}

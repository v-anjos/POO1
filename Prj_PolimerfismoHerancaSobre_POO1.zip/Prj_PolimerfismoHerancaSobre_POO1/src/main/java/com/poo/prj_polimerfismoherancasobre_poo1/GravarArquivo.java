package com.poo.prj_polimerfismoherancasobre_poo1;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;


public class GravarArquivo {
        public void escreverArq(){
        File f = new File ("Obejtos.txtx");
        
        try
        {
            
         FileWriter fw = new FileWriter (f, true);
         PrintWriter pw = new PrintWriter(fw);
         pw.println(p.cadastrar);
         fw.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}

package com.poo.prj_polimerfismoherancasobre_poo1.models;

public class Pessoa
{
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String cadastrar()
    {
        return "Nome: "+this.getNome();
    }

    
}

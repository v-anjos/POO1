package com.poo.prj_polimerfismoherancasobre_poo1.models;

public class PessoaJuridica extends Pessoa
{

    private String cnpj;
    private String inscricaoEstadual;

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getInscricaoEstadual() {
        return inscricaoEstadual;
    }

    public void setInscricaoEstadual(String inscricaoEstadual) {
        this.inscricaoEstadual = inscricaoEstadual;
    }
    
     @Override
    public void cadastrar()
    {
        System.out.println("Pessoa Juridica");
    }
    

}

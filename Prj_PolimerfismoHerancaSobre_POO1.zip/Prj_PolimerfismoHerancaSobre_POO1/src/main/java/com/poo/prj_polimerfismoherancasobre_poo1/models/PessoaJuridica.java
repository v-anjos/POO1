package com.poo.prj_polimerfismoherancasobre_poo1.models;

public class PessoaJuridica extends Pessoa
{

    private String cnpj;
    private String inscricaoEstadual;

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getInscricaoEstadual() {
        return inscricaoEstadual;
    }

    public void setInscricaoEstadual(String inscricaoEstadual) {
        this.inscricaoEstadual = inscricaoEstadual;
    }
    
     @Override
    public String cadastrar()
    {
         return "Nome :"+super.getNome() "CNPJ: "+this.getCnpj()"Inscr. Estadual: "+this.getInscricaoEstadual();
    }
    

}

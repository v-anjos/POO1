/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prj_exemplo_bancodedados_poo1;

import com.poo.prj_exemplo_bancodedados_poo1.dao.PessoaDAO;
import com.poo.prj_exemplo_bancodedados_poo1.menu.Menu2;
import com.poo.prj_exemplo_bancodedados_poo1.models.Pessoa;
import com.poo.prj_exemplo_bancodedados_poo1.util.Conexao;

/**
 *
 * @author user
 */
public class Prj_Exemplo_BancoDeDados_POO1 {

    public static void main(String[] args) {
       /*Conexao c = new Conexao();
        //c.conectar();
        Pessoa p = new Pessoa();
        PessoaDAO pDAO = new PessoaDAO();
        
        p.setNome("Teste 1");
        p.setCpf("11122233356");
        p.setIdade(20);
        
        pDAO.salvar(p);
        
        System.out.println(p.getId_pessoa());*/
       
      Menu2.menu();
        
    }
}
